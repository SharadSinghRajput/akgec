export default function Example() {
    return (
        <section className="isolate py-6 sm:py-20 overflow-hidden bg-white ">
            <h2 className="text-2xl font-light text-center tracking-tight text-gray-900 sm:text-4xl">
            The Echoes of Success -<br/>
            Hear More from Our Esteemed Graduates!
            </h2>
            <p className="mt-6 text-xl leading-8 text-gray-600 px-6 sm:px-20 text-center">
            Discover the enriching stories and valuable insights directly from our accomplished graduates.
            </p>
            <div className="relative mx-auto max-w-2xl py-10 sm:py-10 lg:max-w-4xl ">
                <figure className="grid rounded-3xl grid-cols-1 border items-center gap-x-6 gap-y-8 lg:gap-x-10">
                    <div className="relative col-span-2 lg:col-start-1 lg:row-start-2 ">
                        <blockquote className="">
                            <p className="text-base px-4 py-2 md:px-4 sm:px-4 lg:px-0 sm:text-base md:text-xl font-light text-gray-900">
                                Commodo amet fugiat excepteur sunt qui ea elit cupidatat ullamco consectetur ipsum elit consequat. Elit sunt proident ea nulla ad nulla dolore ad pariatur tempor non. Sint veniam minim et ea.
                            </p>
                        </blockquote>
                    </div>
                    <div className="col-end-1 w-16 lg:row-span-4 lg:w-72">
                        <img
                            alt=""
                            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=576&h=576&q=80"
                            className="bg-indigo-50 rounded-md"
                        />
                    </div>
                    <figcaption className="lg:col-start-1 lg:row-start-3">
                        <div className="text-lg sm:text-lg md:text-xl font-normal text-red-900">Name Yadav</div>
                        <div className="mt-1 text-gray-500">Placed in etc</div>
                    </figcaption>
                </figure>
            </div>
        </section>
    )
}
