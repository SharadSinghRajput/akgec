export default function PlacementHighlights() {
    return (
        <div className="flex flex-col-reverse lg:flex-row h-full">
            <div className="flex w-full h-full lg:w-1/2 flex-col lg:flex-row justify-center items-center bg-white overflow-hidden">
                <div className="grid grid-cols-1 sm:grid-cols-2">
                    <div className="relative max-w-96 max-h-72 bg-blue-300">
                        <img src="/image/slider-home/gysa.png" alt="Rahul Kumar" className="w-full object-cover pt-12 overflow-hidden" />
                        <div className="absolute top-0 right-0 p-4 text-white">
                            <div className="flex items-center justify-end">
                                <img
                                    src="/image/slider-home/6.webp"
                                    alt="Ageas Federal"
                                    className="h-14 w-full max-h-10 max-w-20 sm:w-24 md:w-28 rounded-lg"
                                />
                            </div>
                            <h3 className="text-base sm:text-base md:text-xl lg:text-xl xl:text-xl font-normal">Rahul Kumar</h3>
                            <p className="text-xs sm:text-xs md:text-base lg:text-base xl:text-base font-normal">B.Tech 2021-25</p>
                        </div>
                    </div>
                    <div className="relative max-w-96 max-h-72 shadow-lg bg-red-300">
                        <img src="/image/slider-home/gysa.png" alt="Rahul Kumar" className="w-full object-cover pt-12" />
                        <div className="absolute top-0 right-0 p-4 text-white">
                            <div className="flex items-center justify-end">
                                <img
                                    src="/image/slider-home/6.webp"
                                    alt="Ageas Federal"
                                    className="h-14 w-full max-h-10 max-w-20 sm:w-24 md:w-28 rounded-lg"
                                />
                            </div>
                            <h3 className="text-base sm:text-base md:text-xl lg:text-xl xl:text-xl font-normal">Rahul Kumar</h3>
                            <p className="text-xs sm:text-xs md:text-base lg:text-base xl:text-base font-normal">B.Tech 2021-25</p>
                        </div>
                    </div>
                    <div className="relative max-w-96 max-h-72 shadow-lg bg-green-300">
                        <img src="/image/slider-home/gysa.png" alt="Rahul Kumar" className="w-full object-cover pt-12" />
                        <div className="absolute top-0 right-0 p-4 text-white">
                            <div className="flex items-center justify-end">
                                <img
                                    src="/image/slider-home/6.webp"
                                    alt="Ageas Federal"
                                    className="h-14 w-full max-h-10 max-w-20 sm:w-24 md:w-28 rounded-lg"
                                />
                            </div>
                            <h3 className="text-base sm:text-base md:text-xl lg:text-xl xl:text-xl font-normal">Rahul Kumar</h3>
                            <p className="text-xs sm:text-xs md:text-base lg:text-base xl:text-base font-normal">B.Tech 2021-25</p>
                        </div>
                    </div>
                    <div className="relative max-w-96 max-h-72 w-full h-full shadow-lg bg-orange-300 ">
                        <img src="/image/slider-home/gysa.png" alt="Rahul Kumar" className="w-full object-cover pt-12" />
                        <div className="absolute top-0 right-0 p-4 text-white">
                            <div className="flex items-center justify-end">
                                <img
                                    src="/image/slider-home/6.webp"
                                    alt="Ageas Federal"
                                    className="h-14 w-full max-h-10 max-w-20 sm:w-24 md:w-28 rounded-lg"
                                />
                            </div>
                            <h3 className="text-base sm:text-base md:text-xl lg:text-xl xl:text-xl font-normal">Rahul Kumar</h3>
                            <p className="text-xs sm:text-xs md:text-base lg:text-base xl:text-base font-normal">B.Tech 2021-25</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="flex-grow w-full lg:w-1/2 flex justify-center bg-blue-500 items-center text-white pb-10 ">
                <div className="w-full h-full max-w-4xl text-center ">
                    <h2 className="text-2xl md:text-3xl text-left mt-10 md:text-center px-5 md:px-20 ">Placements Overview</h2>
                    <p className="text-lg mt-3 md:text-2xl md:font-extralight font-light md:mt-3 text-left md:text-center px-5 md:px-20">A brief summary of Placements 2023-24 Batch</p>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8 mb-8">
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                        <div className="text-start px-5">
                            <p className="text-3xl md:text-2xl lg:text-2xl xl:text-2xl font-extralight mt-8">9124</p>
                            <p className="text-sm md:text-sm font-light">Placement Offers</p>
                        </div>
                    </div>

                    <div className="flex justify-center space-x-4 z-10">
                        <button className="bg-yellow-400  text-blue-900 font-semibold px-6 py-2 rounded-full">
                            APPLY TODAY
                        </button>
                        <button className="border border-white text-white font-semibold px-6 py-2 rounded-full">
                            VIEW PLACEMENTS
                        </button>
                    </div>
                </div>
            </div>

        </div>
    );
}
