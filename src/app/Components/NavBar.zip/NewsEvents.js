const posts = [
    {
        id: 1,
        title: 'Boost your conversion rate',
        href: '#',
        description:
            'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel iusto corrupti dicta laboris incididunt.',
        imageUrl:
            'https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3603&q=80',
        date: 'Mar 16, 2020',
        datetime: '2020-03-16',
        category: { title: 'Marketing', href: '#' },
        author: {
            name: 'Michael Foster',
            role: 'Co-Founder / CTO',
            href: '#',
            imageUrl:
                'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
        },
    },
    {
        id: 1,
        title: 'Boost your conversion rate',
        href: '#',
        description:
            'Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel iusto corrupti dicta laboris incididunt.',
        imageUrl:
            'https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3603&q=80',
        date: 'Mar 16, 2020',
        datetime: '2020-03-16',
        category: { title: 'Marketing', href: '#' },
        author: {
            name: 'Michael Foster',
            role: 'Co-Founder / CTO',
            href: '#',
            imageUrl:
                'https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
        },
    },
    // More posts...
]

export default function Example() {
    return (
        <div className="bg-gray-100/50 py-10">
            <h2 className="text-2xl font-light text-center tracking-tight text-gray-900 sm:text-4xl">
                Shining in the Limelight
            </h2>
            <p className="mt-6 text-xl leading-8 text-gray-600 px-6 sm:px-20 text-center">
                Diam nunc lacus lacus aliquam turpis enim. Eget hac velit est euismod lacus. Est non placerat nam arcu.
                Cras purus nibh cursus sit eu in id.
            </p>
            <div className="mx-auto max-w-7xl py-10">
                <div className="mx-auto flex flex-col items-center gap-16 lg:mx-0 lg:max-w-none lg:flex-row">
                <div className="w-full lg:max-w-lg border rounded-t-2xl rounded-b-2xl  hover:shadow-lg">

                        <img
                            alt=""
                            src="https://images.unsplash.com/photo-1606857521015-7f9fcf423740?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1344&h=1104&q=80"
                            className="w-full rounded-2xl bg-gray-50 object-cover lg:aspect-auto lg:h-80 md:h-64"
                        />
                        <h2 className="mt-4 text-start text-lg font-medium text-gray-700 px-4">
                            Arjuna Award for CU’s Kabaddi Star Pawan Kumar Sehrawat
                        </h2>
                        <p className="mt-4 text-start text-base font-light text-gray-700 px-4 pb-4">
                            Chandigarh University student and India Men's Kabaddi Team Captain Pawan Kumar Sehrawat is among 26 Indian athletes to get the Arjuna Award for their extraordinary performances in their respective fields. Mr Sehrawat was recognized for his outstanding contribution to the world of Kabaddi by the Ministry of Youth Affairs & Sports, Government of India.
                        </p>
                        <div className="p-4">
                        <button
                            type="button"
                            className="rounded-md  bg-indigo-50 px-2.5 py-1.5 text-sm font-semibold text-indigo-600 shadow-sm hover:bg-indigo-100"
                        >
                            Button text
                        </button>
                    </div>
                    </div>

                    <div className="w-full lg:max-w-xl">
                        {posts.map((post) => (
                            <article key={post.id} className="relative isolate flex flex-col gap-8 lg:flex-row">
                                <div className="mb-4 relative h-3/4 aspect-[16/12] sm:aspect-[2/1] lg:aspect-square lg:w-64 lg:shrink-0">
                                    <img
                                        alt=""
                                        src={post.imageUrl}
                                        className="absolute inset-0 h-full w-full rounded-2xl bg-gray-50 object-cover"
                                    />
                                    <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" />
                                </div>
                                <div className="flex flex-col  justify-between">
                                    <div className="group relative">
                                        <h3 className="mt-3 text-lg font-semibold leading-6 text-gray-900 group-hover:text-gray-600">
                                            {post.title}
                                        </h3>
                                        <p className="mt-5 text-sm leading-6 text-gray-600">
                                            {post.description}
                                        </p>
                                    </div>
                                </div>
                            </article>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}
