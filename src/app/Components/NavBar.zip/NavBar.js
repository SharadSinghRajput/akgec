'use client'

import { useState } from 'react'
import {
    Dialog,
    DialogPanel,
    Disclosure,
    DisclosureButton,
    DisclosurePanel,
    Popover,
    PopoverButton,
    PopoverPanel,
} from '@headlessui/react'
import {
    ArrowPathIcon,
    Bars3Icon,
    ChartPieIcon,
    CursorArrowRaysIcon,
    FingerPrintIcon,
    SquaresPlusIcon,
    XMarkIcon,
} from '@heroicons/react/24/outline'
import { ChevronDownIcon, PhoneIcon } from '@heroicons/react/20/solid'

const products = [
    { icon: ChartPieIcon },
    { icon: CursorArrowRaysIcon }
]

export default function Example() {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

    return (
        <header className="bg-white">
            <nav aria-label="Global" className="mx-auto flex max-w-7xl items-center justify-between p-4 lg:px-6 relative">
                <div className="flex ">
                    <a href="#" className="-m-1 p-1">
                        <img alt="" src="/image/slider-home/AKGEC_1_0.png" className="h-16 w-auto" />
                    </a>
                </div>
                <div className="flex lg:hidden">
                    <button
                        type="button"
                        onClick={() => setMobileMenuOpen(true)}
                        className="-m-2 inline-flex items-center justify-center rounded-md p-2 text-gray-700"
                    >
                        <span className="sr-only">Open main menu</span>
                        <Bars3Icon aria-hidden="true" className="h-6 w-6" />
                    </button>
                </div>
                <div className="hidden lg:flex lg:gap-x-8 justify-start items-center">
                    <Popover className="relative">
                        <PopoverButton className="flex items-center gap-x-1 text-sm font-semibold leading-6 text-gray-900">
                            Campus
                            <ChevronDownIcon aria-hidden="true" className="h-5 w-5 flex-none text-gray-400" />
                        </PopoverButton>

                        <PopoverPanel
                            transition
                            className="absolute top-full z-10 mt-2 w-screen max-w-md overflow-hidden rounded-3xl bg-white shadow-lg ring-1 ring-gray-900/5 transition data-[closed]:translate-y-1 data-[closed]:opacity-0 data-[enter]:duration-200 data-[leave]:duration-150 data-[enter]:ease-out data-[leave]:ease-in"
                        >
                            <div className="p-3 grid grid-cols-2 gap-3">
                                {products.map((item, index) => (
                                    <div
                                        key={index}
                                        className="group relative flex justify-center rounded-lg text-sm hover:bg-gray-50"
                                    >
                                        <div className="h-32 w-32 p-3 rounded-lg bg-gray-50 flex items-center justify-center">
                                            <item.icon
                                                aria-hidden="true"
                                                className="h-28 w-28 text-gray-600"
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </PopoverPanel>
                    </Popover>

                    <a href="#" className="text-sm font-semibold leading-6 text-gray-900">
                        Library
                    </a>
                    <a href="#" className="text-sm font-semibold leading-6 text-gray-900">
                        Student Services
                    </a>
                    <a href="#" className="text-sm font-semibold leading-6 text-gray-900">
                        Contact us
                    </a>
                    <div className="flex items-center justify-center p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full max-w-md mx-auto">
                        <div className="flex items-center space-x-3">
                            <div className="bg-white p-2 rounded-full flex items-center justify-center">
                                <PhoneIcon className="h-5 w-5 text-cyan-500" aria-hidden="true" />
                            </div>
                            <div>
                                <p className="text-white text-sm">Admission Helpline</p>
                                <p className="text-white font-bold text-base">1800121288800</p>
                            </div>
                        </div>
                        <div className="flex items-center ml-3">
                            <button className="text-white p-2 rounded-full hover:bg-blue-700">
                                {/* Button content */}
                            </button>
                            <Bars3Icon className="text-white mr-2 h-6" aria-hidden="true" />
                        </div>
                    </div>
                    <div className="flex justify-center items-center mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-5 w-5 text-gray-600">
                            <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                        </svg>
                    </div>
                </div>
            </nav>
            <nav className="bg-gradient-to-r bg-gray-600 bg-opacity-60 p-2 rounded-full max-w-6xl mx-auto backdrop-blur-5xl">
                <ul className=" justify-between items-center text-black font-semibold text-sm">
                    <li className="relative group">
                        <button className="px-3 py-2 focus:outline-none">ABOUT</button>
                        <div className="absolute left-0 mt-1 hidden group-hover:block bg-white text-black rounded-lg shadow-lg p-4 w-[1000px]">
                            <div className="flex">
                                <div className="w-1/2 pr-4">
                                    <div className="flex">
                                        <div className="w-1/2 pr-4">
                                            <h3 className="font-bold text-md">WHO WE ARE</h3>
                                            <ul className="mt-2">
                                                <li className="py-1 hover:underline">Overview</li>
                                                <li className="py-1 hover:underline">Our Identity</li>
                                                <li className="py-1 hover:underline">Vision & Mission</li>
                                                <li className="py-1 hover:underline">Leadership</li>
                                                <li className="py-1 hover:underline">Core Values</li>
                                                <li className="py-1 hover:underline">Recognition & Approvals</li>
                                                <li className="py-1 hover:underline">Awards & Rankings</li>
                                                <li className="py-1 hover:underline">Institutional Social Responsibility</li>
                                                <li className="py-1 hover:underline">CU Edge</li>
                                            </ul>
                                        </div>
                                        <div className="w-1/2">
                                            <div>
                                                <h3 className="font-bold text-md">RELATED LINKS</h3>
                                                <ul className="mt-2">
                                                    <li className="py-1 hover:underline">Institutes & Departments</li>
                                                    <li className="py-1 hover:underline">Admissions</li>
                                                    <li className="py-1 hover:underline">Scholarships</li>
                                                    <li className="py-1 hover:underline">Governance</li>
                                                    <li className="py-1 hover:underline">Hostel Facility</li>
                                                    <li className="py-1 hover:underline">Student Services</li>
                                                    <li className="py-1 hover:underline">How to Reach Us?</li>
                                                    <li className="py-1 hover:underline">GATI Charter Institution</li>
                                                    <li className="py-1 hover:underline">ABET Engineering Accreditation</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-1/2 ">
                                    <div className="col-span-2 mt-4 bg-cover bg-center">
                                        <div className="grid grid-cols-2 gap-0 mt-2 text-xs bg-blue-500">
                                            <div className="flex flex-col items-center justify-center max-h-48 max-w-48 sm:w-24 sm:h-24 w-full h-full border border-gray-300 ">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="sm:h-10 h-20">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
                                                </svg>
                                                <span className="mt-2">Human Dignity</span>
                                            </div>
                                            <div className="flex flex-col items-center justify-center max-h-48 max-w-48 sm:w-24 sm:h-24 w-full h-full border border-gray-300 ">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="sm:h-10 h-20">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
                                                </svg>
                                                <span className="mt-2">Human Dignity</span>
                                            </div>
                                            <div className="flex flex-col items-center justify-center max-h-48 max-w-48 sm:w-24 sm:h-24 w-full h-full border border-gray-300 ">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="sm:h-10 h-20">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
                                                </svg>
                                                <span className="mt-2">Human Dignity</span>
                                            </div>
                                            <div className="flex flex-col items-center justify-center max-h-48 max-w-48 sm:w-24 sm:h-24 w-full h-full border border-gray-300 ">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="sm:h-10 h-20">
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />
                                                </svg>
                                                <span className="mt-2">Human Dignity</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </nav>
            <Dialog open={mobileMenuOpen} onClose={setMobileMenuOpen} className="lg:hidden">
                <div className="fixed inset-0 z-10" />
                <DialogPanel className="fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
                    <div className="flex items-center justify-between">
                        <a href="#" className="-m-1 p-1">
                            <span className="sr-only">Your Company</span>
                            <img
                                alt=""
                                src="/image/slider-home/AKGEC_1_0.png"
                                className="h-8 w-auto"
                            />
                        </a>
                        <button
                            type="button"
                            onClick={() => setMobileMenuOpen(false)}
                            className="-m-2 rounded-md p-2 text-gray-700"
                        >
                            <span className="sr-only">Close menu</span>
                            <XMarkIcon aria-hidden="true" className="h-6 w-6" />
                        </button>
                    </div>
                    <div className="mt-6 flow-root">
                        <div className="-my-6 divide-y divide-gray-500/10">
                            <div className="space-y-2 py-4">
                                <Disclosure as="div" className="-mx-3">
                                    <DisclosureButton className="group flex w-full items-center justify-between rounded-lg py-2 pl-3 pr-3.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50">
                                        Campus
                                        <ChevronDownIcon aria-hidden="true" className="h-5 w-5 flex-none group-data-[open]:rotate-180" />
                                    </DisclosureButton>
                                    <DisclosurePanel className="mt-2 space-y-2">
                                        <div className="p-3 grid grid-cols-2 gap-3">
                                            {products.map((item, index) => (
                                                <div
                                                    key={index}
                                                    className="group relative flex justify-center rounded-lg text-sm hover:bg-gray-50"
                                                >
                                                    <div className="h-32 w-32 p-3 rounded-lg bg-gray-50 flex items-center justify-center">
                                                        <item.icon
                                                            aria-hidden="true"
                                                            className="h-28 w-28 text-gray-600"
                                                        />
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </DisclosurePanel>
                                </Disclosure>
                                <a
                                    href="#"
                                    className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                                >
                                    Features
                                </a>
                                <a
                                    href="#"
                                    className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                                >
                                    Marketplace
                                </a>
                                <a
                                    href="#"
                                    className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                                >
                                    Company
                                </a>
                            </div>
                        </div>
                    </div>
                </DialogPanel>
            </Dialog>
        </header>
    )
}
