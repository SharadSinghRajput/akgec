import { Fragment } from 'react'
import { StarIcon } from '@heroicons/react/20/solid'
import { Tab, TabGroup, TabList, TabPanel, TabPanels } from '@headlessui/react'

const product = {
    name: 'Application UI Icon Pack',
    version: { name: '1.0', date: 'June 5, 2021', datetime: '2021-06-05' },
    price: '$220',
    description:
        'The Application UI Icon Pack comes with over 200 icons in 3 styles: outline, filled, and branded. This playful icon pack is tailored for complex application user interfaces with a friendly and legible look.',
    highlights: [
        '200+ SVG icons in 3 unique styles',
        'Compatible with Figma, Sketch, and Adobe XD',
        'Drawn on 24 x 24 pixel grid',
    ],
    imageSrc: '/image/slider-home/fee-structure-bg-5.webp',
    imageAlt: 'Sample of 30 icons with friendly and fun details in outline, filled, and brand color styles.',
}

function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
}

export default function Example() {
    return (
        <div className="bg-white">
            <div className="mx-auto px-4 py-16 sm:px-6 sm:py-24 lg:max-w-7xl lg:px-8">
            <h2 className="text-2xl font-light text-center tracking-tight text-gray-900 sm:text-4xl">
            The Echoes of Success -<br/>
            Hear More from Our Esteemed Graduates!
            </h2>
            <p className="mt-6 mb-6 text-xl leading-8 text-gray-600 px-6 sm:px-20 text-center">
            Discover the enriching stories and valuable insights directly from our accomplished graduates.
            </p>
                <div className="lg:grid lg:grid-cols-1 lg:grid-rows-1 lg:gap-x-8 lg:gap-y-10 xl:gap-x-16">
                    <div className="lg:col-span-4 lg:row-end-1 relative">
                        <img
                            alt={product.imageAlt}
                            src={product.imageSrc}
                            className="object-cover object-center h-full rounded-lg w-full"
                        />
                        <div className="absolute inset-0 pb-4 flex flex-col items-start justify-end bg-black bg-opacity-50 rounded-lg p-4">
                            <h2 className="text-white text-xs sm:text-base md:text-2xl lg:text-3xl font-light mb-2">
                                Cosmopolitan Campus
                            </h2>
                            <p className="text-white text-[10px] sm:text-sm md:text-base lg:text-base font-light mb-2 w-full sm:w-1/2 md:w-1/2 lg::w-1/2">
                                CU's global student body fosters personal growth through diverse cultural interactions, spanning 65+ countries and regions across India.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
